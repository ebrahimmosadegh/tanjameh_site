﻿
namespace Tanjameh.Features.Admin.Banner.Services;

public partial class AdminBannerService
{
    partial void OnBannerUpdated(Core.Entities.Banner item)
    {
        
    }
}
