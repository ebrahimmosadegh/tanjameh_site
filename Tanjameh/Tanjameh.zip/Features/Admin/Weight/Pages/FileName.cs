﻿namespace Tanjameh.Features.Admin.Weight.Pages
{
    public class FileName
    {
    }
}
