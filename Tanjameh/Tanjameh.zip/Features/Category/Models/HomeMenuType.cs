﻿namespace Tanjameh.Features.Category.Models;



public enum HomeMenuType
{
    Men,
    Women,
    Sale
}
