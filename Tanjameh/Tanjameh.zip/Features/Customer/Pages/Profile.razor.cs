using Microsoft.AspNetCore.Components;

namespace Tanjameh.Features.Customer.Pages;

public partial class Profile : ComponentBase
{
}