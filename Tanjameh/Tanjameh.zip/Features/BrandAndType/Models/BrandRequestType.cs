﻿namespace Tanjameh.Features.BrandAndType.Models;

public enum BrandRequestType
{
    Brand,
    ProductType
}
