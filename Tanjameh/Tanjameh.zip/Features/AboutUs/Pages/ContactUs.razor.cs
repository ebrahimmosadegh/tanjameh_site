using Microsoft.AspNetCore.Components;

namespace Tanjameh.Features.ContactUs.Pages;

public partial class ContactUs : ComponentBase
{
}