using System;

namespace Tanjameh.BackgroundServices.Constants;

public static class HttpClientNames
{
    public const string AsosRapidApi = "AsosRapidApi";
    public const string AsosApi = "AsosApi";
    // public const string AsosApiV2 = "AsosApiV2";

}
