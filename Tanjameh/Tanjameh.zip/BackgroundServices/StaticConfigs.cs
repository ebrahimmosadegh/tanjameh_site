﻿using Tanjameh.BackgroundServices.ViewModel;

namespace Tanjameh.BackgroundServices;

public static class StaticConfigs<T>
{
    public static bool StartWorkerService = false;
    public static T GetFormat;
}


