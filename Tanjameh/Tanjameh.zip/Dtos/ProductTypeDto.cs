﻿namespace Tanjameh.Dtos;

public class ProductTypeDto
{
    public int? ProductTypeId { get; set; }

    public string? Name { get; set; } = string.Empty;

    public string Url { get; set; } = string.Empty;
}
