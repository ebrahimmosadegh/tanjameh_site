namespace Tanjameh.Dtos;

public class Lookup
{
    public int Id { get; set; }
    public string? Title { get; set; }
}