﻿namespace Tanjameh.Dtos;

public class ProductCategoryDto
{
    public int ProductId { get; set; }

    public string Name { get; set; } = string.Empty ;

    public string Url { get; set; } = string.Empty ;
}
