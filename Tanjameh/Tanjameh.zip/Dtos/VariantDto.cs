﻿namespace Tanjameh.Dtos;

public record VariantDto(int Id, string? DisplaySize, long? ApiId);
